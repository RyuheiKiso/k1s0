# golden-fixture

Golden fixture sample (auto-regenerated)

## 概要

`k1s0-scaffold tier2-go-service` から生成された tier2 Go ドメインサービス。`tier2` 階層に位置し、`go` で実装される。

## 開発

```bash
go build ./cmd/golden-fixture
./golden-fixture --listen :8080 --tier1-target localhost:50001
```

## 関連

- 所有チーム: @k1s0/test
- 所属システム: k1s0
- テンプレート: [`src/tier2/templates/go-service/`](https://github.com/k1s0/k1s0/tree/main/src/tier2/templates/go-service)（metadata.name: `tier2-go-service`）
