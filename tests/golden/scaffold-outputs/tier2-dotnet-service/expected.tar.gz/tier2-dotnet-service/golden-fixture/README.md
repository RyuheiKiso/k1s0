# golden-fixture

Golden fixture sample (auto-regenerated)

`k1s0-scaffold tier2-dotnet-service` から生成された tier2 .NET ドメインサービス。

## 開発

```bash
dotnet run --project K1s0.Tier2.GoldenFixture.csproj
```

`http://localhost:8080/healthz` で疎通確認。

- 所有チーム: @k1s0/test
- 所属システム: k1s0
- ルート名前空間: `K1s0.Tier2.GoldenFixture`
