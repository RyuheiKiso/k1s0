// k1s0-scaffold が生成した golden-fixture のエントリポイント。
// Golden fixture sample (auto-regenerated)
using K1s0.Sdk;
using K1s0.Tier2.Common.Auth;

var builder = WebApplication.CreateBuilder(args);

// k1s0 Client を Singleton として登録（DI 経由で各 endpoint で参照）。
builder.Services.AddSingleton(_ => new K1s0Client(new K1s0Config
{
    Target = builder.Configuration.GetValue<string>("K1s0:Target") ?? "http://localhost:50001",
    TenantId = builder.Configuration.GetValue<string>("K1s0:TenantId") ?? "tenant-golden-fixture",
    Subject = builder.Configuration.GetValue<string>("K1s0:Subject") ?? "golden-fixture",
}));

// docs §共通規約「認証認可」: T2_AUTH_MODE=off/hmac/jwks の 3 mode を環境変数で切替。
// production では jwks（Keycloak 等）を選び、開発時のみ off で立ち上げる。
builder.Services.AddK1s0JwtBearer();

var app = builder.Build();

// 認証 / 認可 middleware を pipeline に組み込む（順序: Authentication → Authorization）。
app.UseAuthentication();
app.UseAuthorization();

// /healthz: liveness（認証不要）。
app.MapGet("/healthz", () => Results.Ok("ok")).AllowAnonymous();
// /readyz: readiness（認証不要）。採用初期 で tier1 facade health check に置換予定。
app.MapGet("/readyz", () => Results.Ok("ready")).AllowAnonymous();

// /sample-write: 採用組織のドメインロジックに置換するサンプル endpoint。
// 共通規約「認証認可」: 業務 endpoint は RequireAuthorization で JWT 必須化。
app.MapPost("/sample-write", async (K1s0Client client, CancellationToken ct) =>
{
    var data = System.Text.Encoding.UTF8.GetBytes(DateTime.UtcNow.ToString("O"));
    var etag = await client.State.SaveAsync("valkey-default", "golden-fixture/last-call", data, ct: ct);
    return Results.Ok(new { saved = true, etag });
}).RequireAuthorization();

app.Run();
