# golden-fixture

Golden fixture sample (auto-regenerated)

## 開発

```bash
go run ./cmd/golden-fixture --listen :8080 --tier1-target localhost:50001
```

`POST http://localhost:8080/graphql` で GraphQL クエリを受ける。

- 所有チーム: @k1s0/test
- 所属システム: k1s0
