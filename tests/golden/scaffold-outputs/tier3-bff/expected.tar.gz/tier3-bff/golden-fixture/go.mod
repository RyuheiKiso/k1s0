// k1s0-scaffold 生成: golden-fixture BFF。
module github.com/k1s0/golden-fixture

go 1.22

require (
	github.com/k1s0/sdk-go v0.0.0
)

replace github.com/k1s0/sdk-go => ../sdk/go
