// golden-fixture React エントリポイント（k1s0-scaffold 生成）。
import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { App } from "./App";

const container = document.getElementById("root");
if (!container) {
  throw new Error("root element not found");
}
createRoot(container).render(
  <StrictMode>
    <App />
  </StrictMode>
);
