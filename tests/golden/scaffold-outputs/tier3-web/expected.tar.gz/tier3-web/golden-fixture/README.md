# golden-fixture

Golden fixture sample (auto-regenerated)

`k1s0-scaffold tier3-web` から生成された tier3 Web SPA。

## 開発

```bash
pnpm install
pnpm dev
```

`http://localhost:5173/` で開発 server が立ち上がる。

- 所有チーム: @k1s0/test
- 所属システム: k1s0
